#!/bin/bash

cd "$(dirname "$0")"

# Prompt for ngrok credentials
if [ -z "$NGROK_TOKEN" ]; then
  read -p "🔐 Enter your ngrok authtoken: " NGROK_TOKEN
fi

if [ -z "$NGROK_DOMAIN" ]; then
  read -p "🌐 Enter your ngrok domain (e.g. custom-subdomain.ngrok.app):" NGROK_DOMAIN
fi

export NGROK_TOKEN
export NGROK_DOMAIN
export DOMAIN="$NGROK_DOMAIN"
export SAFE_DOMAIN=$(echo "$NGROK_DOMAIN" | sed 's|https://||g' | sed 's|[-.]|_|g')

UUID=$(cat /proc/sys/kernel/random/uuid)
USER_ID="orch-${UUID}"
TIMESTAMP=$(date -u +%Y-%m-%dT%H:%M:%SZ)

# Internal-only identity + referrals
mkdir -p /tmp/orchestrate
echo "{\"user_id\": \"$USER_ID\", \"installed_at\": \"$TIMESTAMP\"}" > /tmp/orchestrate/system_identity.json
echo '{ "referral_count": 0, "referral_credits": 0, "tools_unlocked": ["json_manager"] }' > /tmp/orchestrate/referrals.json

# Clone runtime repo into temp
git clone https://github.com/unmistakablecreative/orchestrate-core-runtime.git /tmp/runtime
cd /tmp/runtime

# Create required runtime folder not tracked in repo
mkdir -p semantic_memory

# Build instruction files
envsubst < openapi_template.yaml > /app/openapi.yaml
envsubst < instructions_template.json > /app/custom_instructions.json

# Build paste file
echo "📎 === CUSTOM INSTRUCTIONS ===" > /app/_paste_into_gpt.txt
cat /app/custom_instructions.json >> /app/_paste_into_gpt.txt
echo -e "\n\n📎 === OPENAPI.YAML ===" >> /app/_paste_into_gpt.txt
cat /app/openapi.yaml >> /app/_paste_into_gpt.txt

# Launch ngrok + server
ngrok config add-authtoken "$NGROK_TOKEN"
ngrok http --domain="$NGROK_DOMAIN" 8000 > /dev/null &

sleep 3
exec uvicorn jarvis:app --host 0.0.0.0 --port 8000
